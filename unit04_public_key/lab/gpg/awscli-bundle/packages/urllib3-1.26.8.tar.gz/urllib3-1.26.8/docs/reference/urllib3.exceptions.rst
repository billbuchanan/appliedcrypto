Exceptions
==========

.. automodule:: urllib3.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
